<h1 align="center">NA20B040 CS5380 A07</h1>

This is an implementation of the tasks given in A07. Requires Docker and Docker compose

## How To Use

compose up docker-compose.yaml

Each of the services run in different ports

* Prometheus: http://localhost:9090/
* Grafana: http://localhost:3000/
* FastAPI: http://localhost:8000/
